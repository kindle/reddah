---
name: 🐛 Bug Report
about: If you want to report that something isn't working as expected.
---

## Type of report

Bug

## Provide detailed reproduction steps (if any)

1. …
2. …
3. …

### Expected result

*What is the expected result of the above steps?*

### Actual result

*What is the actual result of the above steps?*

## Other details

* Browser: …
* OS: …
* CKEditor version: …
* Installed CKEditor plugins: …
